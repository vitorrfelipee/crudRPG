/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author marco
 */
public class Acessorio {
    private String nome, atributoAlterado, descr;
    private int idAcessorio, valorAlterado;

    public String getNome() {
        return nome;
    }

    public String getAtributoAlterado() {
        return atributoAlterado;
    }

    public String getDescr() {
        return descr;
    }

    public int getIdAcessorio() {
        return idAcessorio;
    }

    public int getValorAlterado() {
        return valorAlterado;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setAtributoAlterado(String atributoAlterado) {
        this.atributoAlterado = atributoAlterado;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }

    public void setIdAcessorio(int idAcessorio) {
        this.idAcessorio = idAcessorio;
    }

    public void setValorAlterado(int valorAlterado) {
        this.valorAlterado = valorAlterado;
    }
    
    
}
