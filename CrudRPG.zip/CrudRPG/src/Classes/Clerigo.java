/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author marco
 */
public class Clerigo {
    private int id, idTalisman, idArmaPrimaria, idAcessorio;

    public int getId() {
        return id;
    }

    public int getIdTalisman() {
        return idTalisman;
    }

    public int getIdArmaPrimaria() {
        return idArmaPrimaria;
    }

    public int getIdAcessorio() {
        return idAcessorio;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setIdTalisman(int idTalisman) {
        this.idTalisman = idTalisman;
    }

    public void setIdArmaPrimaria(int idArmaPrimaria) {
        this.idArmaPrimaria = idArmaPrimaria;
    }

    public void setIdAcessorio(int idAcessorio) {
        this.idAcessorio = idAcessorio;
    }
    
}
