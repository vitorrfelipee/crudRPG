/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author marco
 */
public class Cajado {
    private String nome, proeficiencia, descr;
    private int idCajado;

    public String getNome() {
        return nome;
    }

    public String getProeficiencia() {
        return proeficiencia;
    }

    public String getDescr() {
        return descr;
    }

    public int getIdCajado() {
        return idCajado;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setProeficiencia(String proeficiencia) {
        this.proeficiencia = proeficiencia;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }

    public void setIdCajado(int idCajado) {
        this.idCajado = idCajado;
    }
    
}
