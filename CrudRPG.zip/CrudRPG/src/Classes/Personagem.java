/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author marco
 */
public class Personagem {
    private String nome, genero, classe;
    private int idPersonagem, idUsuario, idRaca, vigor, mana, estamina, forca,
            destreza, inteligencia, fe, sorte;

    public String getNome() {
        return nome;
    }

    public String getGenero() {
        return genero;
    }

    public int getIdPersonagem() {
        return idPersonagem;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public int getIdRaca() {
        return idRaca;
    }
    
    public String getClasse() {
        return classe;
    }
    

    public int getVigor() {
        return vigor;
    }

    public int getMana() {
        return mana;
    }

    public int getEstamina() {
        return estamina;
    }

    public int getForca() {
        return forca;
    }

    public int getDestreza() {
        return destreza;
    }

    public int getInteligencia() {
        return inteligencia;
    }

    public int getFe() {
        return fe;
    }

    public int getSorte() {
        return sorte;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public void setIdPersonagem(int idPersonagem) {
        this.idPersonagem = idPersonagem;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public void setIdRaca(int idRaca) {
        this.idRaca = idRaca;
    }

    public void setVigor(int vigor) {
        this.vigor = vigor;
    }

    public void setMana(int mana) {
        this.mana = mana;
    }

    public void setEstamina(int estamina) {
        this.estamina = estamina;
    }

    public void setForca(int forca) {
        this.forca = forca;
    }

    public void setDestreza(int destreza) {
        this.destreza = destreza;
    }

    public void setInteligencia(int inteligencia) {
        this.inteligencia = inteligencia;
    }

    public void setFe(int fe) {
        this.fe = fe;
    }

    public void setSorte(int sorte) {
        this.sorte = sorte;
    }

    public void setClasse(String classe) {
        this.classe = classe;
    }
    
}
