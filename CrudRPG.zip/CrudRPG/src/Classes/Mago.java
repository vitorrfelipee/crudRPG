/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author marco
 */
public class Mago {
    private int id, idCajado, idArmaPrimaria, idAcessorio;

    public int getId() {
        return id;
    }

    public int getIdCajado() {
        return idCajado;
    }

    public int getIdArmaPrimaria() {
        return idArmaPrimaria;
    }

    public int getIdAcessorio() {
        return idAcessorio;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setIdCajado(int idCajado) {
        this.idCajado = idCajado;
    }

    public void setIdArmaPrimaria(int idArmaPrimaria) {
        this.idArmaPrimaria = idArmaPrimaria;
    }

    public void setIdAcessorio(int idAcessorio) {
        this.idAcessorio = idAcessorio;
    }
    
    
}
