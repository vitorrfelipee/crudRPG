/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author marco
 */
public class Raca {
    private String nome;
    private int idRaca;

    public String getNome() {
        return nome;
    }

    public int getIdRaca() {
        return idRaca;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setIdRaca(int idRaca) {
        this.idRaca = idRaca;
    }
    
    
}
